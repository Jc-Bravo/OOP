#ifndef __EXAMPLE__
#define __EXAMPLE__
	
class Example {
		
private:
	
	// (1)number to 
	static int nums;
	int num;
	int Data;
public:
	
	Example(int data);
	void getData();
	~Example();

};
		
#endif